/*package test0919;

public class test3 {

	public static void main(String[] rags) {
		// TODO Auto-generated method stub
		try {
			float f = Float.parseFloat(star);
		}
		catch (NumberFormatException NFS) {
			f=0;
		}
		finally {
			System.out.println(f);
		}
	}
	public static void main1(String[] rags) {
		parse("Korea");
	}
} */
